package sample1;

import java.util.StringTokenizer;

public class TokenUser {
	String str[];
	void tokenConverts(StringTokenizer s){
		str = new String[s.countTokens()];
		for(int i =0; s.hasMoreTokens();i++){
			 char ar[] = s.nextToken().toString().toCharArray();
			 System.out.println(revChars(ar));
			 str[i]=new String(revChars(ar));
		}
	}
	char[] revChars(char ar[]){
		char arr[] = new char[ar.length];
		for(int i =0;i<ar.length;i++){
			arr[ar.length-1-i]=ar[i];
		}
		return arr;
	}
	void alphaSort(){
		for(int i=0; i<str.length-1;i++){
			for(int j=i;j<str.length;j++){
				if(compStr(str[i],str[j])){
					String temp = new String(str[j]);
					str[j]=str[i];
					str[i]=temp;
				}
			}
		}
	}
	boolean compStr(String s1, String s2){
		int var=s1.compareTo(s2);
		if(var>0)
			return true;
		else
			return false;
	}
	void tokenPrinter(){
		for(int i=0;i<str.length;i++){
			System.out.println(str[i]);
		}
	}
}
