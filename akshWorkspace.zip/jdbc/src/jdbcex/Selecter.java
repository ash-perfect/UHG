package jdbcex;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Selecter extends Deleter{
	Connection con;
	void selectMan(){
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","root");
			String Query = "select * from register where uname = ? order by id";
			PreparedStatement stmt = con.prepareStatement(Query);
			System.out.println("Select name");
			String name = sc.next();
			stmt.setString(1, name);
			ResultSet rs = stmt.executeQuery();
			while(rs.next())
				System.out.println(rs.getString(1) +"\t " +rs.getString(2) + " \t \t"+ rs.getInt(4) + "\t" + rs.getString(5));
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	void selectAll(){
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","root");
			Statement stmt = con.createStatement();
			String Query = "select * from register order by id";
			ResultSet rs = stmt.executeQuery(Query);
			while(rs.next())
				System.out.println(rs.getString(1) +"\t " +rs.getString(2) + " \t \t"+ rs.getString(3));
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
