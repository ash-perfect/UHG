package jdbcex;

import java.sql.PreparedStatement;

public class Register extends ConnectionMan{
	boolean checker;
	void registerMan(){
		checker=true;
		StringBuffer uname=new StringBuffer("");
		StringBuffer pass=new StringBuffer("");
		long mob=0;
		StringBuffer gen=new StringBuffer("");;
		
		while(checker){
		System.out.println("Enter a username");
		uname=new StringBuffer(sc.next());
		checkU(uname.toString());}
		checker = true;
		while(checker){
		System.out.println("Enter a new password");
		pass= new StringBuffer(sc.next());
		checkPass(pass.toString());}
		checker = true;
		while(checker){
		System.out.println("Enter your gender, \'male\' or \'female\'");
		gen = new StringBuffer(sc.next());
		checkGen(gen.toString());}
		checker = true;
		while(checker){
			System.out.println("Enter mobile number");
			mob= sc.nextLong();
			checkMob(mob);
		}
		try {
			String Query = "insert into register values(autoID.nextval,?,?,?,?,'Bangalore')";
			PreparedStatement pstmt = con.prepareStatement(Query);
			pstmt.setString(1, uname.toString());
			pstmt.setString(2, pass.toString());
			pstmt.setLong(3, mob);
			pstmt.setString(4, gen.toString());
			int n=0;
//			int n = stmt.executeUpdate("insert into register values(autoID.nextval,'Optum','itsoptum','9449332114','male','Bangalore')");
			n=pstmt.executeUpdate();
			if(n>0)
				System.out.println("Data inserted");
			else
				System.out.println("There's a problem");

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

	private void checkMob(long mob) {
		// TODO Auto-generated method stub
		long x= mob/1000000000;
		if(x>=1 && x<10){
			checker =false;
			return;}
		else {
			System.out.println("Invalid mobile number");
		}
	}

	private void checkGen(String gen) {
		// TODO Auto-generated method stub
		if(gen.toLowerCase().equals("male")||gen.toLowerCase().equals("female")){
			checker=false;
			return;
		}
		else
			System.out.println("Invalid gender");
	}

	private void checkPass(String pass) {
		// TODO Auto-generated method stub
		if(pass.length()<8){
			System.out.println("Password too short");
			return;
		}
		if(Character.isLowerCase(pass.toCharArray()[0])){
			System.out.println("First letter upper case please");
			return;
		}
		char[] ch = pass.toCharArray();
		boolean flag = false;
		boolean flag2 = false;
		for(int i =0;i<pass.length();i++){
			if(Character.isLetter(ch[i]))
				;
			else if(Character.isDigit(ch[i]))
				flag2=true;
			else
				flag=true;
		}
		if(flag == false){
			System.out.println("Please have a special character");
			return;
		}
		if(flag2== false){
			System.out.println("Please end with a number");
			return;
		}
		checker=false;
	}

	private void checkU(String uname) {
		// TODO Auto-generated method stub
		if(uname.length()<8){
			System.out.println("Password too short");
			return;
		}
		char[] ch = uname.toCharArray();
		boolean flag = false;
		for(int i =0;i<uname.length();i++){
			if(Character.isLetterOrDigit(ch[i]))
				;
			else
				flag=true;
		}
		if(flag){
			System.out.println("Shouldn\'t contain special chars");
			return;
		}
		checker=false;
		
	}
}
