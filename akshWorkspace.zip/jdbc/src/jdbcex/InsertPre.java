package jdbcex;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class InsertPre extends InsertIntoRegx{
	Scanner sc = new Scanner(System.in);
	public void executerPre()	{
		System.out.println("Enter the username");
		String name = sc.next();
		System.out.println("Enter the password");
		String pass = sc.next();
		System.out.println("Enter the mobile number");
		int mobile = sc.nextInt();
		System.out.println("Enter the gender");
		String gen = sc.next();
		System.out.println("Enter the Location");
		String loca = sc.next();
		String Query = "insert into register values(autoID.nextval,?,?,?,?,?)";
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("asdasf");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","root");
			PreparedStatement pstmt = con.prepareStatement(Query);
			pstmt.setString(1, name);
			pstmt.setString(2, pass);
			pstmt.setInt(3, mobile);
			pstmt.setString(4, gen);
			pstmt.setString(5, loca);
			int n=0;
//			int n = stmt.executeUpdate("insert into register values(autoID.nextval,'Optum','itsoptum','9449332114','male','Bangalore')");
			n=pstmt.executeUpdate();
			if(n>0)
				System.out.println("Data inserted");
			else
				System.out.println("There's a problem");
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
	}

}
