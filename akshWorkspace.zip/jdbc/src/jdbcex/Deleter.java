package jdbcex;

import java.sql.*;

public class Deleter extends Updater{
	String deleteVal(){

		String full = "delete from register where uname = 'united' " ;
		return full;
	}
	void deleteMan(){
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","root");
			String Query = "delete from register where uname = ? " ;
			PreparedStatement sta = con.prepareStatement(Query);
			System.out.println("Enter the username of the account to be deleted");
			String name = sc.next();
			sta.setString(1, name);
			int n = sta.executeUpdate();
			if(n>0)
				System.out.println("It is deleted");
			else
				System.out.println("Failure");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
}
