package jdbcex;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;

public class SomeCredits {
	static Connection con = null;
	public static void main(String[] args) {
		try {
			con = ConnectionMan.establish();
			String inser = "{call somLec(?,?,?)}";
			CallableStatement cstmt = con.prepareCall(inser);
			cstmt.setInt(3, 40);
			cstmt.registerOutParameter(1, java.sql.Types.VARCHAR);
			cstmt.registerOutParameter(2, java.sql.Types.VARCHAR);
			cstmt.execute();
			String major = cstmt.getString(1);
			System.out.println(major);
			
//			
//			while(rs.next())
//				System.out.println(rs.getString(2)+"     "+rs.getString(3));
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
}
