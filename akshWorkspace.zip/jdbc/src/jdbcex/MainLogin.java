package jdbcex;

import java.util.Scanner;

public class MainLogin {
	public static void main(String[] args) {
		ConnectionMan cm = new ConnectionMan();
		cm.establish();
		LoginIt lg= new LoginIt();
		System.out.println("1. Register     2.Login");
		Scanner sc = new Scanner(System.in);
		int x =sc.nextInt();
		if(x==1)
			lg.registerMan();
		else
			lg.loginMan();
		sc.close();
	}
}
