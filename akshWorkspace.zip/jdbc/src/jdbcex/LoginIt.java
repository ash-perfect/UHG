package jdbcex;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LoginIt extends Register{
	void loginMan(){
		System.out.println("Login please\n Username:");
		String uname = sc.next();
		System.out.println("Password:");
		String pwd = sc.next();
		try {
			String Query = "select pwd from register where uname = ? order by id";
			PreparedStatement stmt = con.prepareStatement(Query);
			stmt.setString(1, uname);
			ResultSet rs = stmt.executeQuery();
			while(rs.next())
				if(rs.getString(1).equals(pwd))
					System.out.println("Logged in");
				else 
					System.out.println("Invalid Password");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
}
