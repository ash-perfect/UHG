package jdbcex;

import java.sql.*;
import java.util.Scanner;

public class CallableThing {
	static Connection con = null;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "asdf";
		Scanner sc = new Scanner(System.in);
		FileFilter = new FileFilter();
		try {
			con=ConnectionMan.establish();
			if(con == null)
				System.out.println("connection not established");
			else
				System.out.println("connection made");
			String inser= "{call addLec(?,?,?,?,?)}";
			CallableStatement cstmt = con.prepareCall(inser);
			cstmt.setInt(1, 4567);
			cstmt.setString(2, "Auba");
			cstmt.setString(3, "meyang");
			cstmt.setString(4, "Flips");
			cstmt.setInt(5, 93);
			int n = cstmt.executeUpdate();
			if(n>0)
				System.out.println("Inserted man");
			else
				System.out.println("FAILURE!!");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		
	}

}
