package jdbcex;

import java.util.Scanner;

public class MainJDBC{
 public static void main(String[] args) {
	 Scanner sc = new Scanner(System.in);
Alterer d = new Alterer();
int x;boolean b=true;
d.selectAll();
	while(b){
		System.out.println("Enter option man ");
		x = sc.nextInt();
		switch(x){
		case 1:
			d.insertMan();
			break;
		case 2:
			d.updateMan();
			break;
		case 3:
			d.deleteMan();break;
		case 4:
			d.selectMan();
			break;
		case 5:
			d.createMan();
			break;
		case 6:
			d.alterIt();
			break;
		default: 
				b=false;
				System.out.println("Exiting");
				break;
		}
	}
	sc.close();

//	d.deleteMan();
}
}
