package jdbcex;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Alterer extends Creater{
	void alterIt(){
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","root");
			Statement stmt = con.createStatement();
			String query = "alter table uniqueone add author varchar2(20)";
			int n = stmt.executeUpdate(query);
			if(n==0)
				System.out.println("Altered the table");
			else
				System.out.println("Failure");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

	}
}
