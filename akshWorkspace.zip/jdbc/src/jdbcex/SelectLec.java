package jdbcex;

import java.sql.CallableStatement;
import java.sql.Connection;

public class SelectLec {
	static Connection con = null;
	public static void main(String[] args) {
		try {
			con = ConnectionMan.establish();
			String inser = "{call getLec(?,?,?)}";
			CallableStatement cstmt = con.prepareCall(inser);
			cstmt.setInt(1, 4269);
			cstmt.registerOutParameter(2, java.sql.Types.VARCHAR);
			cstmt.registerOutParameter(3, java.sql.Types.INTEGER);
			cstmt.executeQuery();
			String major = cstmt.getString(2);
			int credit= cstmt.getInt(3);
			System.out.println(major+"  "+credit);
//			
//			while(rs.next())
//				System.out.println(rs.getString(2)+"     "+rs.getString(3));
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
}
/*
 * Write a procedure whose current credits are first name and last name where current credits greater than 50;
 * 
 */


