package jdbcex;

import java.sql.CallableStatement;
import java.sql.Connection;

public class UpdateLec {
	static Connection con = null;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			con=ConnectionMan.establish();
			if(con == null)
				System.out.println("connection not established");
			else
				System.out.println("connection made");
			String inser= "{call upLec(?,?)}";
			CallableStatement cstmt = con.prepareCall(inser);
			cstmt.setInt(1, 2341);
			cstmt.setString(2, "Bill");
			int n = cstmt.executeUpdate();
			if(n>0)
				System.out.println("Updated man");
			else
				System.out.println("FAILURE!!");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		
	}
}
