package jdbcex;

import java.sql.*;
import java.util.Scanner;

public class ConnectionMan {
	static Connection con;
	Scanner sc = new Scanner(System.in);
	static Connection establish(){
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","root");
			return con;
		}
		catch(Exception e){
			e.printStackTrace();
			return con;
		}
	}
}
