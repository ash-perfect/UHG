package jdbcex;

import java.sql.*;

public class Updater extends InsertPre{
	String updateVal(){

		String full = "update register set pwd = 'notopium' where uname = 'Optum' " ;
		return full;
	}
	void updateMan(){
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","root");
			String Query = "update register set pwd = ? where uname = ? " ;
			PreparedStatement presta = con.prepareStatement(Query);
			System.out.println("Enter the username ");
			System.out.println("Enter the new passworrd");
			String name = sc.next();
			String pass = sc.next();
			presta.setString(1, pass);
			presta.setString(2,name);
			int n = presta.executeUpdate();
			if(n>0)
				System.out.println("It is updated");
			else
				System.out.println("Failure");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
}
