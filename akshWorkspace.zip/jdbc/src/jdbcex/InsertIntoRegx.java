package jdbcex;

import java.sql.*;
import java.util.Scanner;

public class InsertIntoRegx {
	Scanner sc = new Scanner(System.in);
	String readValues(){
		System.out.println("Enter the username");
		String name = sc.next();
		System.out.println("Enter the password");
		String pass = sc.next();
		System.out.println("Enter the mobile number");
		int mobile = sc.nextInt();
		System.out.println("Enter the gender");
		String gen = sc.next();
		System.out.println("Enter the Location");
		String loca = sc.next();
		String full = "insert into register values(autoID.nextval, '"+ name +"','" +pass +"','"+ mobile  +"','"+ gen +"','"+ loca+"')" ;
		System.out.println("Command beingf executed"+full);
		return full;
	}
	
	public void insertMan()	{
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","root");
			Statement stmt = con.createStatement();
			int n=0;
//			int n = stmt.executeUpdate("insert into register values(autoID.nextval,'Optum','itsoptum','9449332114','male','Bangalore')");
			n=stmt.executeUpdate(readValues());
			if(n>0)
				System.out.println("Data inserted");
			else
				System.out.println("There's a problem");
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
	}
	
}
