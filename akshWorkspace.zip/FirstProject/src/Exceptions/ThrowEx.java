package Exceptions;

public class ThrowEx {
	
}
