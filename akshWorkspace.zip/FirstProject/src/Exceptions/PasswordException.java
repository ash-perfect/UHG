/**
 * 
 */
package Exceptions;

/**
 * @author Administrator
 *
 */
public class PasswordException extends Exception {
	PasswordException(){
		super("Password not correct");
	}
	PasswordException(String s){
		super(s);
	}
	PasswordException(String[] s){
		for (int i = 0; i < s.length; i++) {
			if(s[i]==null)
				continue;
			System.out.println(i+1+". "+s[i]);
		}
	}
	
}
