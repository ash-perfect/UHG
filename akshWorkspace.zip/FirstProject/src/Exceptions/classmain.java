package Exceptions;

public class classmain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			
		} finally {
			// TODO: handle finally clause
			System.out.println("Thank you bus driver :)");
		}
		
	}

}
