package Exceptions;

public class UserName extends Throwable{
	UserName(){
		super("Invilid Madte");
	}
	UserName(String s){
		super(s);
		System.out.println("Let me tell ya , you suck");
	}
}
