
package Exceptions;

public class NullException{
	public static void main(String[] str){
		try{
		char ar[] = new char[50];
		System.out.println(ar[52]);
		throw(new ArrayIndexOutOfBoundsException("Something is happening"));
		}
		catch(ArrayIndexOutOfBoundsException ae){
			System.out.println("Well well  is " + ae);
		}
		catch(Exception e){
			System.out.println("Well well well the exception is " + e);
		}
		finally{
			System.out.println("Exdoedcksaovc");
		}
	}
}
