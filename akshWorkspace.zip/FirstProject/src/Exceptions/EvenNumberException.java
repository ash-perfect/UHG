package Exceptions;

public class EvenNumberException extends Throwable{
	EvenNumberException(){
		super("Even number exception");
	}
	EvenNumberException(String msg){
		super(msg);
	}
}
