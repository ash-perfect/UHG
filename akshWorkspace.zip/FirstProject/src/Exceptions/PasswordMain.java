/**
 * 
 */
package Exceptions;

import java.util.Scanner;

/**
 * @author Administrator
 *
 */
public class PasswordMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		String p=sc.nextLine();
		String[] s=new String[4];
		
		try {
			boolean sym=false,cor=true;
			char[] ch=p.toCharArray();
			int ite=0;
			for (int i = 0; i < ch.length; i++) {
				if(Character.isAlphabetic(ch[i])||(Character.isDigit(ch[i])))
					;
				else
					sym=true;
			}
			if(p.length()<8){
				cor=false;
				s[ite]="Length should be 8 chars";
				ite++;
//				throw(new PasswordException("Length should be 8 chars"));
			}
			if(!sym){
				cor=false;
				s[ite]="Symbol is not there";
				ite++;
//				throw(new PasswordException("Symbol is not there"));
			}
			if(Character.isLowerCase(ch[0])){
				cor=false;
				s[ite]="Please start with capital letter";
				ite++;
//				throw(new PasswordException("Please start with capital letter"));
			}
			if(!Character.isDigit(ch[ch.length-1])){
				cor=false;
				s[ite]="End with a number";
//				throw(new PasswordException("End with a number"));
			}
			if(cor)
				System.out.println("Damn, thats some strong PASSWORD");
			else{
				System.out.println("Your password doesn't comply to the following \n");
				throw(new PasswordException(s));
			}
		}
		catch(PasswordException pe){
//			System.out.println("Your password doesn't comply to the following \n");
			System.out.println();
			System.out.println(pe);
		}
		finally {
			// TODO: handle finally clause
			System.out.println();
			System.out.println("Thank you bus driver :)");
		}
	}

}
