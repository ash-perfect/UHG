package Exceptions;

import java.util.Scanner;

public class EvenUserDefinedException {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			int n;
			Scanner sc = new Scanner(System.in);
			n=sc.nextInt();
			sc.close();
			try{
				if(n%2==0)
					throw(new EvenNumberException());
				else
					System.out.println("Odddddddddd");
			}
			catch(EvenNumberException e){
				System.out.println("This si expoi "+e);
			}
	}

}
