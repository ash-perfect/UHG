package Exceptions;

import java.util.Scanner;

public class UserNameCheck {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		String name = sc.nextLine();
		try{
		if(!Character.isUpperCase(name.charAt(0))){
			throw(new UserName());
		}
		else{
			System.out.println("you're good to go");
		}
		}
		catch(UserName e){
			System.out.println("Ok I think the exception is "+ e);
		}
		finally{
			System.out.println("Thank you bus driver");
		}
		
	}

}
