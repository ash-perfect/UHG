package bankthings;

public class salaryAcc extends ProtectedAccount{
	double irate=0.05;
}
