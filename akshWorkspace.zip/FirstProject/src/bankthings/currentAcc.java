package bankthings;

public class currentAcc extends ProtectedAccount{
	double irate=0.07,minbal=10000,pen=0.15;
}
