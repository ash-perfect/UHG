package bankthings;

import java.util.Scanner;

public class MainBank {
	public static void main(String[] str){
		System.out.println("Welcome to Optum bank\n Please enter the option");
		Scanner sc = new Scanner(System.in);
//		System.out.println("5. ");
		BasicAcc ba;
		double add;
		System.out.println("Create Account\n1. SB  2. Salary  3. Current");
		int c=sc.nextInt();
		switch(c){
		case 1: ba=new SBAcc();
		break;
		case 2: ba= new salaryAcc();
		break;
		case 3: ba= new currentAcc();
		break;
		default: ba = new SBAcc();
		break;
		}
		System.out.println("1.Add money  2.Withdraw  3.Check Balance 4.Create Account");
		c=sc.nextInt();
		while(true){
			switch(c){
				case 1: System.out.println("Enter pin");
					ba.checkPin(sc.nextInt());
					System.out.println("How much ?");
					add=sc.nextDouble();
					ba.withDraw(add);
					break;
				case 2: System.out.println("Enter pin");
					ba.checkPin(sc.nextInt());
					System.out.println("How much ?");
					add=sc.nextDouble();
					ba.deposit(add);
					break;
				case 3: System.out.println("Enter pin");
				ba.checkPin(sc.nextInt());
				ba.checkBalance();
				break;
			}
		}
	}
}
