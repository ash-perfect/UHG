package bankthings;

import java.util.Scanner;

public class ProtectedAccount extends BasicAcc{
	private int pin;
	ProtectedAccount(){
		System.out.println("Pin is required to be created. Please enter your 4 digit desired pin");
		Scanner sc = new Scanner(System.in);
		//pin = sc.nextInt();
		sc.close();
	}
	boolean checkPin(int p){
		if(p==pin)
			return true;
		else 
			return false;
	}

}
