package bankthings;

public class SBAcc extends ProtectedAccount{
	double minbal=1000;
	double irate=0.06;
	double pen=0.1;
}
