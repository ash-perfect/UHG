package bankthings;

import java.util.Scanner;

public class BasicAcc {
	double bal,irate,minbal=0,pen=0;
	
	BasicAcc(){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the name");
		//String name=sc.nextLine();
		System.out.println("Account created. ");
		sc.close();
	}
	void checkBalance(){
		checkMin();
		intMonth();
		System.out.println("your balance is "+bal);;
	}
	void checkMin(){
		if(bal<minbal){
			bal=bal- pen*bal;
		}
	}
	void withDraw(double d){
		bal=bal-d;
	}
	void deposit(double d){
		bal=bal+d;
	}
	void intMonth(){
		bal=bal+irate*bal;
	}
	boolean checkPin(int n){
		return false;
	}
}
