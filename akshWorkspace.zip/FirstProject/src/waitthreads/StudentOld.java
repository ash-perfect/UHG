package waitthreads;

public class StudentOld implements Runnable{
	Student emp;//reference variable
	StudentOld(Student emp)
	{
		super();
		this.emp = emp;	
	}
	@Override
	public void run() {
		// Object lock - synchronized block with object name
		 try {
		synchronized (emp){
			 System.out.println(Thread.currentThread().getName()+"is waiting for retirement"+emp.getEname());
				emp.wait();
				
			} 
		 }
		 catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		   System.out.println(Thread.currentThread().getName()+": it's retirement time!! new employee can join");

	}


}
