package waitthreads;

public class StudentNew implements Runnable {
	Student emp;
	StudentNew(Student emp)
    {
    	super();
    	this.emp = emp;
    }
	@Override
	public void run() {
		// TODO Auto-generated method stub
		try{
			synchronized (emp) {
				   System.out.println("Started joining process of " +emp.getEname() );
				   Thread.sleep(1000);
				   emp.setJoined(true);
				   System.out.println("Joining process completed");
				   emp.notify();
				   System.out.println("notified old student");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
