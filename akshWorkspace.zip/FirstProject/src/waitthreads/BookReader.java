package waitthreads;

import java.awt.print.Book;

public class BookReader implements Runnable{
	Book book;
	public BookReader(Book book){
		super();
		this.book = book;
	}
	@Override
	public void run(){
		synchronized (book){
			System.out.println();
			try {
				book.wait();
			} catch (InterruptedException e) {
				// TODO: handle exception
			}
		}
	}
}
