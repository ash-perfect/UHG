package waitthreads;

/*Class Lock - If a static method is marked as Synchrnozied 
and called by a Thread, the whole Class will be locked 
until the method execution completed.*/
public class ClassLock implements Runnable{
	public void run()
    {
        Lock();
    }
 
    public static synchronized void Lock()
    {
        System.out.println(Thread.currentThread().getName());
        synchronized(ClassLock.class)
        {
            System.out.println("in block "
                + Thread.currentThread().getName());
            System.out.println("in block "
                + Thread.currentThread().getName() + " end");
        }
    }
 
    public static void main(String[] args)
    {
    	ClassLock g1 = new ClassLock();
        Thread t1 = new Thread(g1);
        Thread t2 = new Thread(g1);
        ClassLock g2 = new ClassLock();
        Thread t3 = new Thread(g2);
        t1.setName("t1");
        t2.setName("t2");
        t3.setName("t3");
        t1.start();
        t2.start();
        t3.start();
    }
}
