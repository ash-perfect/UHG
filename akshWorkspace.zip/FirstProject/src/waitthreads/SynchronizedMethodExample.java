package waitthreads;

public class SynchronizedMethodExample implements Runnable{
	@Override
	public void run() {
		display();
	}
	
	public synchronized void display(){
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	}

}
