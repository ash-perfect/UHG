package waitthreads;

public class ThreadIPC {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student emp = new Student(123,"rama",23456.75f);
		Student emp1 = new Student(125,"ramya",25901.35f);
		StudentOld eo1 = new StudentOld(emp);
		Thread eot = new Thread(eo1,"empold");
		eot.start();
		try{
			Thread.sleep(1500);
			
		}
		catch (InterruptedException e) {
			  
			   e.printStackTrace();
			  }
		StudentNew en1 = new StudentNew(emp1);
		Thread ent = new Thread(en1,"empnew");
		ent.start();
	}

}
