/**
 * 
 */
package hotel;


/**
 * @author Administrator
 *
 */
public class MainHotel {
	public static void main(String[] str){
		Hotel.methond();
		Booking[] h = new Booking[12];
		boolean boo=true;
		int booked=0,x;
		while(boo){
			System.out.println();
			if(booked!=0)System.out.println("Selected room no is "+ h[booked].roomNo);
			else System.out.println("Please book a room or select room");
			System.out.println("Please enter an option\n 1. Book a room\t 2. Order food\t 3. Room Service\t 4. Get Bill \t 5. Leave room\t 6. Exit\t 7. Change Room \t \n");
			x = Hotel.sc.nextInt();
			switch(x){
			case 1: 
				booked++;
				h[booked]=new Booking();
					h[booked].book();
					break;
			case 2: h[booked].order();
					break;
			case 3: h[booked].service();
					break;
			case 4: h[booked].billPrint();
					break;
			case 5: System.out.println("alright bye");
					booked=0;
			 		break;
			case 6: System.out.println("Bye");
			 		boo=false;
			 		break;
			case 7: 
				System.out.println("1. Previous Room \t2. Next Room\n");
				int no=Hotel.sc.nextInt();
				if(no==1)
				booked--;
				else booked++;
			 		default: System.out.println("Invalid option");
			 		break;
			}
		}
		System.out.println("Exited");
		Hotel.closeSca();
	}
}
