/**
 * 
 */
package hotel;

import java.util.Arrays;
import java.util.Scanner;

/**
 * @author Administrator
 *
 */
public class Hotel {
	protected int bill;
	int bookNo;
	int roomNo;
	static Scanner sc = new Scanner(System.in);
	static int arr[]=new int[12];
	Hotel(){
		
	}
	static void methond(){
		int j=0;
		for(int i =1;i<100;i++)
			if(i%13==0){
				arr[j]=i;
				arr[j]+=100;
				j++;
			}
			else if(i%17==0){
				arr[j]=i;
				arr[j]+=200;
				j++;
			}
	}
	void showrooms(){
		System.out.println("The available rooms are \n");
		Arrays.sort(arr);
		for (int i = 0; i < arr.length; i++) {
			if(arr[i]!=0)System.out.println(arr[i]);
		}
	}
	void billPrint(){
		System.out.println("your bill is :" + bill);
	}
	void service(){
		System.out.println("What service is needed? \n 1. Laundry \t 2. Room Cleaning\n");
		int x = sc.nextInt();
		switch(x){
		case 1: System.out.println("Alright. Doing laundry. \nThe cost is 200Rs which is added to the final bill\n");
				bill+=200;
				break;
		case 2: System.out.println("Cleaning room\n");
		}
	}
	void calculateBill(){
		System.out.println("Your total bill is "+bill);
	}
	static void closeSca(){
		sc.close();
	}
}
