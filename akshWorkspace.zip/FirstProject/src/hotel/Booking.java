/**
 * 
 */
package hotel;


/**
 * @author Administrator
 *
 */
public class Booking extends InhouseRes{
	void book(){
		System.out.println("Please select from our available rooms\nThe cost is 2000Rs for rooms 1xx and 2500Rs for rooms 2xx");
		this.showrooms();
		System.out.println("Enter the room no");
		int x = sc.nextInt();
		roomNo=x;
		boolean boo=false;
		for (int i = 0; i < arr.length; i++) {
			if(arr[i]==x){
				arr[i]=0;
				if(x/100==1)
					bill+=2000;
				else if(x/100==2)
					bill+=2500;
				boo=true;
			}
		}
//		sc.close();//
		if(!boo)
			System.out.println("Invalid room no, try again");
	}
}
