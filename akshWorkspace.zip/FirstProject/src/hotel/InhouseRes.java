/**
 * 
 */
package hotel;


/**
 * @author Administrator
 *
 */
public class InhouseRes extends Hotel{
	void order(){
		System.out.println("What do you want to order?\n 1. Soup\t 100Rs\n2. South Meals\t 250Rs\n3. North Meals\t 300Rs\n4. Ice Scream\t 150Rs\n5. Exit");
		boolean boo=true;
		while(boo){
		int x = sc.nextInt();
		switch(x){
		case 1: System.out.println("Order placed, you can order again or exit");
				bill+=100;
				break;
		case 2: System.out.println("Order placed, you can order again or exit");
		bill+=250;
		break;
		case 3: System.out.println("Order placed, you can order again or exit");
		bill+=300;
		break;
		case 4: System.out.println("Order placed, you can order again or exit");
		bill+=150;
		break;
		case 5: boo=false;
			break;
			default: System.out.println("Enter correct option");
			break;
		}}
	}
	
}
