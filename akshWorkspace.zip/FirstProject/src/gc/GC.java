package gc;

public class GC {
	public static void main(String[] str){
		GC c = new GC();
		try{
			c.finalize();
		}
		catch(Throwable e){
			e.printStackTrace();
		}
//		System.gc();
		Runtime.getRuntime().gc();
		System.out.println("Garbage Collected");
	}
}
