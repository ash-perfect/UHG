package clonewars;
import java.util.System;
public class ExceptionTest extends Thread{
	class TestException extends Exception{}
	public void runTest() throws TestException{}
	public void test() throws Exception
	{
		runTest();
	}
	ExceptionTest e = new ExceptionTest();
	Thread t = new Thread(e);
	
}
