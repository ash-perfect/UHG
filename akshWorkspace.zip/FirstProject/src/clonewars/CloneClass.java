package clonewars;

public class CloneClass implements Cloneable{
	int a ;
	CloneClass getClone(){
		try {
			return (CloneClass) super.clone();
		} catch (CloneNotSupportedException e) {
			// TODO: handle exception
			System.out.println("Cloningi failed");
			return this;
		}
	}
}
