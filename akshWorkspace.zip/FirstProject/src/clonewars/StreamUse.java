package clonewars;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class StreamUse {
	public static void main(String[] args) {
		List<String> namesList = new ArrayList<String>();
		namesList.add("raj");
		namesList.add("ram");
		namesList.add("shram");
		namesList.add("hemanth");
		namesList.add("shiv");
		namesList.add("shri");
		namesList.add("kiran");
		namesList.add("kumar");
		namesList.add("heman");
		namesList.add("krish");
		
		Stream<String> seqstr = namesList.stream();
		Stream<String> parastr = namesList.parallelStream();
		Stream<String> strstream =  parastr.filter(p->p.contains("k"));
		strstream.forEach(p->System.out.println("res pof search"+p));
		
		
		
	}
}
