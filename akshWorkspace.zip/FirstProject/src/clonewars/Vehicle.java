package clonewars;

@FunctionalInterface
public interface Vehicle {
	public void drive();
	default void vstart(){
		System.out.println("its out");
	}
	static void vstarts(){
		System.out.println("Its on");
	}
}

