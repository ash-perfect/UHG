package clonewars;

public class LambEx{

	public static void main(String[] args) {
		Runnable r = new Runnable(){
		@Override
		public void run() {
			// TODO Auto-generated method stub
		System.out.println("I am running");	
		}};
		Thread t = new Thread(r);
		t.start();
		
		Runnable r1 = () -> {
			System.out.println("my runnablel");
		
		};
		Thread t2 = new Thread(r1);
		t2.start();
		InterfaceLM inlm = (s) -> System.out.println(s);
		inlm.printValue("Hey lambda");
	}
	
}
