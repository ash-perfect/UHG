package clonewars;

public class AnonyInter {
	public static void main(String[] args) {
		Vehicle v = new Vehicle(){
			public void drive(){
				System.out.println("Drive method");
			}
		};
		v.drive();
		boolean var = true;
		if(var = false){
			System.out.println("true");
		}
		else
			System.out.println("False");
	}
}
