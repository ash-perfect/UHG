package clonewars;

class Student {
	public void marks(){
		System.out.println("Marks Method");
	}
}
public class AnonymousEx{
	public static void main(String[] a){
		Student s = new Student(){
			public void marks()
			{
				System.out.println("Anonymous Marks Method");
			}
		};
		s.marks();
	}
}