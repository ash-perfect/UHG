package clonewars;

public class Employee implements Cloneable{	
	String s1;
	
	Employee getClone(){
		try {
			System.out.println("CLoned like a boss");
			return (Employee)super.clone();
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("employees not to b ecloned");
			return this;
		}
	}

}
