package clonewars;

@FunctionalInterface
public interface InterfaceLM {
	void printValue(String s);
}
