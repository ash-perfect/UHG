package clonewars;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Maps2List {
	public static void main(String[] args) {
		Map<Integer,String> hm = new HashMap<Integer, String>();
		hm.put(1001,"DairyMilk");
		hm.put(1002, "FIveStar");
		hm.put(1004, "Perk");
		hm.put(1005, "KitKat");

		List<Integer> restokey = new ArrayList<>();
		List<String> restovalues = 
				hm.entrySet().stream()
				.sorted(Map.Entry.<Integer,String>comparingByKey().reversed())
				.peek(e -> restokey.add(e.getKey()))
				.map(x -> x.getValue())
				.filter(x -> !"Perk".equalsIgnoreCase(x))
				.collect(Collectors.toList())
				;
		restokey.forEach(System.out::println);
		restovalues.forEach(System.out::println);
	}
}
