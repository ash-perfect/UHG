package clonewars;


public class EmployeeMain {
 public static void main(String[] args) {
	Employee e1 = new Employee();
	Employee e2;
	e1.s1 = "e001";
	e2=e1.getClone();
	System.out.println(e2.s1);
	e1.s1 = "asoijdcvoisadv";
	System.out.println(e2.s1);
}
}
