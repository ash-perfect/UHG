package threads;

public class ThreadPriorityEx extends Thread{
	public void run(){
		System.out.println("Run method started");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ThreadPriorityEx te = new ThreadPriorityEx();
		ThreadPriorityEx te2 = new ThreadPriorityEx();
		ThreadPriorityEx te3 = new ThreadPriorityEx();
		
		te.setPriority(6);
		System.out.println(te.getPriority());
		System.out.println(Thread.MAX_PRIORITY);
		System.out.println(Thread.MIN_PRIORITY);
		System.out.println(Thread.holdsLock(te));
		Thread.interrupted();
		System.out.println(te2.isInterrupted());
		
	}

}
