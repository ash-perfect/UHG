/**
 * 
 */
package threads;

/**
 * @author Administrator
 *
 */
public class MultipleThreads {
	public synchronized void me(){
		System.out.println("In me");
	}
	public synchronized void me2(){
		System.out.println("In me2");
	}

	public static void main(String args[])
	   {
	      Counting cnt = new Counting();
	      MultipleThreads  mt = new MultipleThreads();
	      mt.me();
	      mt.me2();
	      try
	      {
	    	 while(cnt.isAlive())
	         {
	           System.out.println("Main thread will be alive till the child thread is live");
				System.out.println(Thread.currentThread().getId());
	           Thread.sleep(1500);
	         }
	      }
	       catch(InterruptedException e)
	      {
	        System.out.println("Main thread interrupted");
	      }
	      System.out.println("Main thread's run is over" );
	   }

}
