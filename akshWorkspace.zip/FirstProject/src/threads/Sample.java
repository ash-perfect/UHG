/**
 * 
 */
package threads;

/**
 * @author Administrator
 *
 */
public interface Sample {
	void dos();
	void dos1();
}
