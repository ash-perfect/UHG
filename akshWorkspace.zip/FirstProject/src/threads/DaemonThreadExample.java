package threads;

public class DaemonThreadExample extends Thread {

	
	public void run(){
		if(Thread.currentThread().isDaemon())
			System.out.println("Daemon thread executing");
		else
			System.out.println("naut");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DaemonThreadExample dt = new DaemonThreadExample();
		dt.setDaemon(true);
		dt.start();

	}

}
