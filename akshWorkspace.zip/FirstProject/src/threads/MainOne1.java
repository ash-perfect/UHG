/**
 * 
 */
package threads;

/**
 * @author Administrator
 *
 */
public class MainOne1 {
	public static void main(String[] str){
		
	}
}
