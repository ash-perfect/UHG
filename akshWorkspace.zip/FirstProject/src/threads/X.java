package threads;

public class X implements Runnable{
	public static void main(String[] args) {
		X main = new X();
		Thread t = new Thread(main);
		t.start();
	}
	public void run(){}
}