/**
 * 
 */
package threads;

/**
 * @author Administrator
 *
 */
public class Demo extends A implements Sample{
	public static void main(String[] args) {
		A a = new A();
	}
	public void dos(){
		
	}

	/* (non-Javadoc)
	 * @see threads.Sample#dos1()
	 */
	@Override
	public void dos1() {
		// TODO Auto-generated method stub
		
	}
}
