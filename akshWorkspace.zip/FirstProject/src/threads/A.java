/**
 * 
 */
package threads;

/**
 * @author Administrator
 *
 */
public class A {

}
