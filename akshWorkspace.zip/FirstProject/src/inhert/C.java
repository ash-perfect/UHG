package inhert;

public class C extends B{
	void printInfo(){
		System.out.println("C class methong");
		super.printInfo(5);
	}
}
