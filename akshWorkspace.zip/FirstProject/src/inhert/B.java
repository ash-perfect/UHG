package inhert;

public class B extends A{
	void printInfo(int x){
		System.out.println("B class methong");
		super.printInfo(x);
	}
	int printInfo(String s){
		System.out.println("B class methong name"+s);
		return s.length();
	}
}
