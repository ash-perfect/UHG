package inhert;

public class Inheritance {
	Inheritance(){
		System.out.println("I inhert");
		}
	public static void main(String...st){
		C c = new C();
		int x=c.printInfo("nah");
	} 
}
