package inhert;

public class A extends Inheritance{
	
	void printInfo(){
		System.out.println("A class methong");
	}
	void printInfo(int x){
		System.out.println("A methong OVERLOADED");
	}
}
