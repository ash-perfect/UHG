public class FirstProgram {
	public static void main(String[] str)
	{
	for(int i=0;i<10;i++)
	System.out.print("yolo world, this class is bitrcching\n");
	}
}