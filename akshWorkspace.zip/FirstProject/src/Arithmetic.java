import sample1.BitwiseOps;
public class Arithmetic {
	public static void main(String[] str){
		BitwiseOps ad = new BitwiseOps();
		ad.read();
		ad.bitConv();
		ad.bitAnd();
		ad.bitOr();
		ad.bitNot();
		ad.bitXor();
		ad.bitRs();
		ad.bitRsz();
		ad.bitLs();
		ad.bitOrass();
		ad.bitAndass();
		ad.bitXorass();
	}
}
