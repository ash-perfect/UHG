package multipleInterface;

public interface Address {
	void readAddress();
}
