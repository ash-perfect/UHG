package multipleInterface;

class arr extends C{
	public void c2(){
		;
	}
}