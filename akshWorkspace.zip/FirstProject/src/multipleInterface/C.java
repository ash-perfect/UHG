package multipleInterface;

public class C {
	private void c2(){
		;
	}
}

