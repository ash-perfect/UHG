package multipleInterface;

public interface City {
	void readCity();
}
