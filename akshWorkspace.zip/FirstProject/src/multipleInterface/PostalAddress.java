package multipleInterface;

import interFace.DataBase;

public interface PostalAddress extends Address,City,DataBase{
	void readPostalAddress();
}
