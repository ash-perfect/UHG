import java.util.Scanner;

public class DataTypes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Write a java program to add values of the array.
		Scanner sc = new Scanner(System.in);
		System.out.println("enter\n");
		int asize = sc.nextInt();
		char a[] = new char[asize];
		int sum=0;
		for(int i=0;i<asize;i++){
			a[i]=(char)sc.next().charAt(0);
			sum=sum+(int)a[i];}
		System.out.println(sum);
		for(int i=asize-1;i>=0;i--)
			System.out.print(a[i]);
		sc.close();
	}
}
