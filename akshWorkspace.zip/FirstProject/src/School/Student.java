package School;

public class Student {
	protected String name;
	protected int roll;
	void updateInfo(String s,int r){
		name=s;
		roll=r;
	}
}