package School;

public class Marks extends Student{
	private int m1,m2,m3;
	void setMarks(int a,int b, int c){
		m1=a;
		m2=b;m3=c;
	}
	protected int getMarks(){
		int total=m1+m2+m3;
		return total;
	}
}
