package School;

public class Result extends Marks{
	void getResult(){
		System.out.print(name.length()+ name +" has obtained a total of "+getMarks()+" out of 300 and his result is "+name.length());
		if(getMarks()>150)
			System.out.println("Pass");
		else
			System.out.println("Fail");
	}
}
