package School;

import java.util.Scanner;

public class MainSchool {
	public static void main(String[] str){
		Result m=new Result();
		Scanner sc = new Scanner(System.in);
		String s = sc.nextLine();
		m.updateInfo(s,9);
		m.setMarks(45, 32, 9);
		m.getResult();
	}
}
