package sample1;

public class DupliStr {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "I string cool";
		String s2 = "Java programming Language";
		StringBuffer sb = new StringBuffer(s);
		sb.ensureCapacity(25);
		System.out.println(sb.capacity()+" "+sb.length());
		sb.append("Which is immutabWhich is immutabWhich is immutabWhich is immutabWhich is immutable");
		sb.insert(2, "am ");
		System.out.println(sb.capacity()+" "+sb.length());
		sb.setLength(16);
		sb.setCharAt(7, 'x');
		System.out.println(sb);
//		System.out.println(sb.toString());
		System.out.println(sb.capacity()+" "+sb.length());
		
		char[] arr = new char[30];
		sb.getChars(2, 7, arr, 10);
		System.out.println(new String(arr));
//		System.out.println(sb.reverse());
		System.out.println(sb.delete(11, 16));sb.setCharAt(7, 'r');
		System.out.println(sb);
		System.out.println(sb.deleteCharAt(7));
		System.out.println(sb.append("ing"));
		System.out.println(sb.replace(2, 4, "like"));
	}
}
