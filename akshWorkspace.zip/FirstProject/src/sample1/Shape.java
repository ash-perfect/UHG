package sample1;

public class Shape {
	Shape(){
		System.out.println("Imma shape");
	}
	void readBreadth(){
		
	}
	protected void countCorners(){
		
	}

}
