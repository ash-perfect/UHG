package sample1;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

import clonewars.Employee;

public class ListItrEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			List<Employee> li = new ArrayList<Employee>();
			Employee e1 = new Employee();
			Employee e2 = new Employee();
			Employee e3 = new Employee();
			li.add(e1);
			li.add(e2);
			li.add(e3);
			System.out.println(li);
			ListIterator<Employee> elit = li.listIterator();
			while(elit.hasNext())
				System.out.println(elit.next());
			System.out.println("In reverse");
			while(elit.hasPrevious())
				System.out.println(elit.previous());
	}

}
