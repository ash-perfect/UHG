package sample1;

import java.util.Enumeration;
import java.util.Vector;

public class EnumEr {
	public static void main(String[] args) {
		Vector<Float> vt = new Vector<Float>();
		vt.add(342.234f);
		vt.add(567.123f);
		vt.add(567.234f);
		Enumeration<Float> en = vt.elements();
		while (en.hasMoreElements()) {
			System.out.println(en.nextElement());
		}
	}
}
