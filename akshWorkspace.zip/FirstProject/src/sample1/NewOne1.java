package sample1;

import java.util.Scanner;

/*
 * 
 * Program to check if the given angles make right angled triangle or not
 */
public class NewOne1 {
	public static void main(String[] str){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the angles");
		int a=sc.nextInt();
		int b=sc.nextInt();
		int c=sc.nextInt();
		if((a+b+c)!=180)
			System.out.println("Dude not a triangle");
		else if(a==90||b==90||c==90)
			System.out.println("Yeah Right angled triangle");
		else
			System.out.println("Not a right angled triangle");
		sc.close();
	}
}
