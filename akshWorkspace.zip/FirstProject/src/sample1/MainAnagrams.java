package sample1;

import java.util.Scanner;

public class MainAnagrams {
	public static void main(String[] str){
		Scanner sc= new Scanner(System.in);
		String s1 = new String(sc.nextLine());
		String s2 = new String(sc.nextLine());
		s1=s1.toLowerCase();
		s2=s2.toLowerCase();
		System.out.println();
		System.out.println();
		System.out.println(sortIt(s1)+'\n'+sortIt(s2));
		if(sortIt(s1).compareTo(sortIt(s2))==0){
			System.out.println("This is an anagram");
		}
		else
			System.out.println("not anagram");
		
		sc.close();
	}
	static String sortIt(String s){

		char[] ch =s.toCharArray();
		for(int i =0;i<ch.length-1;i++)
			for(int j=i;j<ch.length;j++){
				if(ch[i]>ch[j]){
					char te=ch[i];
					ch[i]=ch[j];
					ch[j]=te;
				}
			}
		String re = new String(ch);
		return re;
	}
}
//I AM LORDVOLDEMORT
//Tom Marvolo Riddle

