package sample1;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

public class HashMapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<Integer,String> hm= new HashMap<Integer,String>(10);
		HashMap<Integer,String> m= new HashMap<Integer,String>(10);
			hm.put(12, "Bankrupt");
			hm.put(23, "Half a girlfriend");
			hm.put(14, "Two States");
			hm.put(15, "Alchemist");
			System.out.println(hm.get(13));
			System.out.println(hm.values());
			System.out.println(hm);
			m.putAll(hm);
			m.replace(14, "LoTR");
			Set sets = hm.entrySet();
			System.out.println(sets);
			Iterator itr = sets.iterator();
			while(itr.hasNext()){
				Entry<Integer,String> mentry = (Entry<Integer,String>)itr.next();
				System.out.println("key is "+mentry.getKey());
				System.out.println("Value is "+ mentry.getValue());
			}
	}
}
