package sample1;

import java.util.List;
import java.util.Vector;

public class Vectory {
	public static void main(String[] args) {
		Vector<Integer> v = new Vector<Integer>();
		v.add(new Integer(2));
		v.add(new Integer(12));
		v.add(new Integer(23));
		v.add(new Integer(21));
		v.add(new Integer(11));
		v.add(new Integer(4));
		v.add(new Integer(6));
		v.add(new Integer(5));
		v.add(new Integer(11));
		for(Integer i : v)
			System.out.print(i+" ");
		System.out.println();
		System.out.println(v.size()/2);
		v.add(v.size()/2,new Integer(42));
		System.out.println(v);
		v.remove(v.size()-1);
		System.out.println(v);
		v.set(v.size()/2, new Integer(69));
		System.out.println(v);
		List<Integer> l = v.subList(2, 5);
		System.out.println(l);
		Vector<Integer> v2= new Vector<Integer>();
		v2.addAll(v);
		v2.add(new Integer(42));
		System.out.println(v2.containsAll(v));
	}
}
