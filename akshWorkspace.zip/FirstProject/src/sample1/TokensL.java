package sample1;

import java.util.StringJoiner;

public class TokensL {
	public static void main(String[] args){
//		String s1 = "This is a Java String";
//		StringTokenizer st = new StringTokenizer(s1," ");
//		System.out.println(st.countTokens());
//		System.out.println(st.toString().length());
//		while(st.hasMoreTokens())
//			System.out.println(st.nextToken());
//		
//		
	}
}
