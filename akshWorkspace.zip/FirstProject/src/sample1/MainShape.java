package sample1;

public class MainShape {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Square s = new Square(66.5f);
		s.area();
		auto(890625);
	}
	public static void auto(long num){
		long sq=num*num;
		long tsq=sq,tnum=num;
		boolean b=true;
		while(tnum!=0){
			if((tnum%10)!=(tsq%10))
				b=false;
			tnum=tnum/10;
			tsq=tsq/10;
		}
		if(b)
			System.out.println(num+ " is an automorphic num. ALERT!!!!!");
		else
			;//System.out.println("Its not. Chill lads");
	}
}
