package sample1;

import java.util.Scanner;

public class Automorphic {
	public static void main(String[] str){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter numebr");
		//int num=sc.nextInt();
		for(long i=0;i<10000000;i++)
//			890625
			auto(i);
		sc.close();
	}
	public static void auto(long num){
		long sq=num*num;
		long tsq=sq,tnum=num;
		boolean b=true;
		while(tnum!=0){
			if((tnum%10)!=(tsq%10))
				b=false;
			tnum=tnum/10;
			tsq=tsq/10;
		}
		if(b)
			System.out.println(num+ " is an automorphic num. ALERT!!!!!");
		else
			;//System.out.println("Its not. Chill lads");
	}
}
