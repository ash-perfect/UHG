package sample1;

import java.util.HashMap;
import java.util.StringJoiner;

public class dupRemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "I have have of a lot of of dups kill kill me";
		String[] ch = s.split(" ");
		HashMap<Integer,String> hm= new HashMap<Integer,String>();
		for(int i=0;i<ch.length;i++)
			hm.put(i, ch[i]);
		for (int i = 0; i < ch.length-1; i++) {
			for (int j = i+1; j < ch.length; j++) {
				if(ch[i].equals(ch[j]))
					hm.remove(j);
			}
		}
		String st= hm.values().toString();
		StringJoiner sj = new StringJoiner(" ");
		for(String a:hm.values()){
			sj.add(a);
		}
		System.out.println(sj);
	}

}
