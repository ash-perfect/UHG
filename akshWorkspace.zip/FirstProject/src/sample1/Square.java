package sample1;

public class Square extends Triangle{
Square(){
	System.out.println("Imma sqaure");
}
Square(float len){
	l=len;
}

protected void countCorners(){
	System.out.println("4 corners");
}
void area(){
	System.out.println(l*l);
}
}
