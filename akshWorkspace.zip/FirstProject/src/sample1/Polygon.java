package sample1;

public class Polygon extends Shape{

	protected void countCorners(){
		System.out.println("4 corners");
	}
}
