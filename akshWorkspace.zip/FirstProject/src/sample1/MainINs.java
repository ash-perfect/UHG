package sample1;

import sample1.OuterClass.InnerClass;
public class MainINs {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		OuterClass outerObject = new OuterClass();
		InnerClass innerObject = outerObject.new InnerClass();
		System.out.println(outerObject.a);
//		innerObject.ac();//
	}
}
