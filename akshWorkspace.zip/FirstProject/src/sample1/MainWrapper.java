package sample1;

import java.util.Scanner;

public class MainWrapper {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 * to convert primitive data types into respective classes
		 * 
//		 */
//			Integer inte = new Integer(65);
//			String sint = inte.toString();
//			System.out.println(sint);
//			System.out.println(inte.floatValue());
//			System.out.println(inte.longValue());
//			System.out.println(Integer.compareUnsigned(-65, 65));
//			System.out.println(inte.hashCode());
//			System.out.println(inte.getClass());
//			System.out.println(inte.MAX_VALUE);
//			System.out.println(Integer.lowestOneBit(7));
//			System.out.println(Integer.highestOneBit(7));
//			System.out.println(Integer.bitCount(15));
//			System.out.println(Integer.numberOfLeadingZeros(565));
//			System.out.println(Integer.reverse(1));
//			Using valueOf func find values stored in an integer object. Find out which is divisible by 5.
			char ch = 'a';
			char ch2 = Character.valueOf(ch);
			System.out.println(ch2);
			Scanner sc = new Scanner(System.in);
			int n = sc.nextInt();
			Integer i = Integer.valueOf(n);
			if(i%5==0)
				System.out.println("It is divisible by 5");
			else
				System.out.println("Not divisible by 5");
			sc.close();
	}

}
