package sample1;

public class StringDemo {
	public static void main(String[] str){
		String s1="This si a str";
		String s2=new String("Heuahidfonfosdncvondsovnfdsonvodfvnofdv");
		char[] sd = {'a','s','d','f'};
		String s5=s2;
		String s3= "This ie A str";
		String s4= new String(sd);
		System.out.println(s1.concat(s2));
		System.out.println(s1.substring(5,7));
		System.out.println(s2.indexOf('u'));
		System.out.println((int)' ');
		System.out.println(s3.compareTo(s1));
		System.out.println(s1.codePointAt(10) + "dfavdfv " + s1.charAt(10));
		}
}
