package sample1;

import java.util.Scanner;
import java.util.StringTokenizer;

public class javaProg {
	public static void main(String[] arg){
			TokenUser t = new TokenUser();
			Scanner sc = new Scanner(System.in);
			String s=sc.nextLine();
			s.toLowerCase();
		StringTokenizer st = new StringTokenizer(s," ");
		t.tokenConverts(st);
		t.alphaSort();
		t.tokenPrinter();
		sc.close();
	}
}