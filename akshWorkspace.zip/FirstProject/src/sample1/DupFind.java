package sample1;
import java.util.*;
public class DupFind {
	public static void main(String[] str){
		List list= new ArrayList();
		char c[]=new char[]{'a','b','e','g','u','u','u','h','e','w','s','a','q','b','e','t','h','h'};
		int l=c.length;
		for(int i=0;i<l;i++){
			int n=0;
			if(!list.contains(c[i]))
				list.add(c[i]);
			else
				continue;
			for(int j=i+1;j<l;j++){
				if(c[i]==c[j])
					n++;
			}

			System.out.println(c[i]+" has "+n+" duplicates");
		}
	}
}
