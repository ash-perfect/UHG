package sample1;

public class SortingArr {
	public static void main(String[] str){
		int arr[] = new int[]{2,4,6,7,8,21,2,4,5,6,45,34,2,12,54,7,56,324,21,234,6,45,34,85,36,215,58,07};
		int l=arr.length;
		for(int i =0;i<l;i++)
			for(int j=0;j<l-1;j++){
				if(arr[j]>arr[j+1]){
					int t=arr[j];
					arr[j]=arr[j+1];
					arr[j+1]=t;
				}
			}
		for(int i=0;i<l;i++)
			System.out.print(arr[i]+" ");
	}
}
