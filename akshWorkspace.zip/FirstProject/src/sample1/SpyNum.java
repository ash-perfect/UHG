package sample1;

import java.util.Scanner;

public class SpyNum {
	public static void main(String[] str){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter numebr");
		int num=sc.nextInt();
		int t=num,s=0,m=1;
		while(t!=0){
			int x=t%10;
			t=t/10;
			s=s+x;
			m=m*x;
		}
		if(s==m)
			System.out.println("Its a spy number. ALERT!!!!!");
		else
			System.out.println("Its not. Chill lads");
		
	}
}
