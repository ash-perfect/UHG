package sample1;

import java.util.HashSet;
import java.util.Iterator;
import java.util.ListIterator;

public class HashSetYo {
	public static void main(String[] args) {
		HashSet<String> sta = new HashSet<String>();
		sta.add("pen");
		sta.add("pencil");
		sta.add("eraser");
		Iterator<String> litr = sta.iterator();
//		ListIterator<Integer> litr = sta.ListIterator();
		while (litr.hasNext()){
			System.out.println(litr.next());
			if("pen".equals(litr.next()))
				litr.remove();
		}
	}
}
