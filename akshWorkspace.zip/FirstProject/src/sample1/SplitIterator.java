package sample1;

import java.util.ArrayList;
import java.util.List;
import java.util.Spliterator;
import java.util.stream.Stream;

public class SplitIterator {
	public static void main(String[] args) {
		List<String> li = new ArrayList<String>();
		li.add("asdf");
		li.add("aafvbfsdf");
		li.add("abfsdf");
		li.add("asbfgbgdf");
		li.add("asdf");
		li.add("ashggnfhndf");
		li.add("ashngdf");
		Spliterator <String> splits = li.spliterator();
//		splits.forEachRemaining(System.out::println);
		Stream<String> str = li.stream();
		System.out.println(splits.getExactSizeIfKnown());
		System.out.println(splits.hasCharacteristics(splits.characteristics()));
		splits.forEachRemaining((n)->System.out.println(n));
	}
}
