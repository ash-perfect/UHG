package sample1;

import java.util.Scanner;

public class Triangle extends Shape{
	Triangle(){
		System.out.println("Imma constructor");
	}
	Scanner sc = new Scanner(System.in);
	float l,b,h;
	void readLength(){
		l=sc.nextInt();
	}
	void readBreadth(){
		b=sc.nextInt();
	}
	void readHeight(){
		System.out.println("Height of triangle");
		h=sc.nextInt();
	}
	
	void area(){
		System.out.println("Area is "+(0.5*b*h));
	}
	void perimeter(){
		
	}
	
}
