package sample1;

import java.util.HashMap;
import java.util.Scanner;

public class FruitHash {
	static Scanner sc = new Scanner(System.in);
public static void main(String[] args) {
	HashMap<String,Float> fh = new HashMap<String,Float>(10);
	fh.put("Apple",12.5f);
	fh.put("Orange", 6.7f);
	fh.put("Pomegranite", 10f);
	fh.put("Grape", 15.23f);
	fh.put("Banana", 8f);
	fh.put("Watermelon", 14.4f);
	while(true){
	System.out.println("1. Buy Fruit \t 2. Exit");
	int x = sc.nextInt();
	Float ft;
	if(x==1)
		ft=bill(fh,sc);
	else
		break;
	System.out.println("Please pay "+ft);
	}
}
static Float bill(HashMap<String,Float> h,Scanner sc){
	Float bil=0f;
	while(true){

		System.out.println(h);
		System.out.println("Wnter the fruit name\t * \"Exit\" to exit");
		String sk= "Exit";
		String s = new String();
		s=sc.next();
		if(sk.equals(s))
			return bil;
		Float f = new Float(h.get(s));
		System.out.println("Quantity?");
		int q= sc.nextInt();
		bil+=q*f;
		
	}
	
}
}
