package sample1;

import java.util.ArrayList;

public class ArrayListDemo {
	public static void main(String[] args) {
		ArrayList<Integer> al  = new ArrayList<Integer>();
		al.add(new Integer(10));
		al.add(new Integer(20));
		al.add(new Integer(30));
		System.out.println(al);
		ArrayList<Integer> al2  = new ArrayList<Integer>();
		al2.addAll(al);
		System.out.println(al2);
		
		al2.remove(1);
		al2.clear();
		al2.addAll(al);
		al2.add(new Integer(23));
		al2.add(new Integer(30));
		al2.removeAll(al);
		al2.remove(new Integer(23));
		System.out.println(al2);
		al2.addAll(al);
		al2.set(2, 45);
		al2.add(0,35);
		al2.addAll(al);
		
		System.out.println(al2.containsAll(al));
		System.out.println(al2);
		for(Integer o : al){
			System.out.println(o);
		}
		
		Object[] a = al.toArray();
		for (int i = 0; i < a.length; i++) {
			System.out.println(a[i]);
		}
		
	}
}