package sample1;

import java.util.Scanner;

public class BitwiseOps {
	Scanner sc = new Scanner(System.in);
	int val1,val2;
	public void read(){
		/**
		 * Docu things
		 */
		System.out.println("Enter First Value");
		val1 = sc.nextInt();
		System.out.println("Enter Sec Value");
		val2 = sc.nextInt();
		sc.close();
	}
	public void conv(int co){
		if(co==0)
			return;
		conv(co/2);
		System.out.print(co%2);
	}
	public void bitConv(){
		conv(val1);
		System.out.print(" on ");
		conv(val2);
		System.out.println();
	}
	public void bitAnd(){
		System.out.println("Bitwise " + (val1&val2));
	}
	public void bitOr(){
		System.out.println("Bitwise " + (val1|val2));
	}
	public void bitNot(){
		System.out.println("Bitwise " + (~val2));
	}
	public void bitXor(){
		System.out.println("Bitwise " + (val1^val2));
	}
	public void bitRs(){
		System.out.println("Bitwise " + (val1>>val2));
	}
	public void bitRsz(){
		System.out.println("Bitwise " + (val1>>>val2));
	}
	public void bitLs(){
		System.out.println("Bitwise " + (val1<<val2));
	}
	public void bitAndass(){
		System.out.println("Bitwise " + (val1&=val2));
	}
	public void bitOrass(){
		System.out.println("Bitwise " + (val1|=val2));
	}
	public void bitXorass(){
		System.out.println("Bitwise " + (val1^=val2));
	}
}
