package sample1;

public class OuterClass {
	 int a=10;
	 void ac(){
		 System.out.println("Im called");
	 }
	 public class InnerClass{
		 public void printer(){
			 System.out.println(a);
		 }
	}
}
