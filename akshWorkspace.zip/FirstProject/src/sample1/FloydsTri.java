package sample1;

public class FloydsTri {
	public static void main(String[] str){
		int n=10,s=1;
		for(int i=0;i<n;i++){
			for(int j=0;j<i;j++){
				System.out.print(s+" ");
				s++;
			}
			System.out.println();
		}
	}	
}
