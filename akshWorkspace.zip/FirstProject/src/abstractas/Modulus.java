/**
 * 
 */
package abstractas;

/**
 * @author Administrator
 *
 */
public class Modulus extends AbstractClasss{

	@Override
	public void add(){
		System.out.println("Overridden");
	}
}
