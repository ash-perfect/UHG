/**
 * 
 */
package abstractas;

/**
 * @author Administrator
 *
 */
public abstract class AbstractClasss {
	void add(){
		System.out.println("Adding");
	}
	void suba(){
		
	}
	
	
}
