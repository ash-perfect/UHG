/**
 * 
 */
package abstractas;

/**
 * @author Administrator
 *
 */
public class MainAbstract extends AbstractClasss{
	public static void main(String[] str){
		Modulus md = new Modulus();
		md.add();
	}
}
