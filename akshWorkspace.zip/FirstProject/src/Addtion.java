import java.util.Scanner;

public class Addtion {
	Scanner sc = new Scanner(System.in);
	int firstVal;
	int secVal;
	public void read(){
		/**
		 * Docu things
		 */
		System.out.println("Enter First Value");
		firstVal = sc.nextInt();
		System.out.println("Enter Sec Value");
		secVal = sc.nextInt();
	}
	public void add(){
		System.out.println("Addtion of two values is "+(firstVal+secVal));
	}
}
