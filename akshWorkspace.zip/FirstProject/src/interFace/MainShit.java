package interFace;

public class MainShit {
	public static void main(String[] str){
		Employee e[]= new Employee[10];
		e[0] = new Employee(1,"Normioe",54000);
		e[0].getInfo();
	}
}
