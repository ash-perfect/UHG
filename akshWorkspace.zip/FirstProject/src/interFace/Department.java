package interFace;

public class Department {
	int did;
	String dname;
	Department(int d,String s){
		did=d;
		dname=s;
	}
	void getInfo(){
		System.out.println("Dept ID: "+did+"\n Dept Name: "+ dname );
	}
}
