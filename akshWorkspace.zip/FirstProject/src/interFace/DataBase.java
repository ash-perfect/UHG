package interFace;

//interface upto java7 doesn't any implementation of the code

public interface DataBase {
	int a=2;
	void connectDB();
	default void ConnectionValues(){
		System.out.println("read shit and shit");
	}
	//Java 8 feature
	static void values(){
		System.out.println("static values");
	}
}
