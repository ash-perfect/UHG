package interFace;

/**
 * @author Administrator
 *
 */
public class DataBaseImp1 implements DataBase{
//	void connectDB(){
	@Override
	public void connectDB(){
		System.out.println("Coonnect ot DB");
	}

}