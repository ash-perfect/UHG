package interFace;

public class Employee {
	int id;
	int sal;
	String name;
	Employee(int i,String s,int z){
		id=i;
		name=s;
		sal=z;
	}
	void getInfo(){
		System.out.println("Employee ID:"+id+"\nName is "+name+" with salary: "+sal);
	}
}
