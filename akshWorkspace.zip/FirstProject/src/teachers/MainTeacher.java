package teachers;

public class MainTeacher{
	public static void main(String[] str){
		//French f = new French(2);
		//f.teaches();
		Teacher t = new Computer();
		System.out.println(t instanceof Computer);
	}
}