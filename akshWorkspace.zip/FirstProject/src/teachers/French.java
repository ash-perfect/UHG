package teachers;

import java.util.Scanner;

public class French extends Teacher{
	int imp=5;
	String name;
	French(){
		System.out.println("I teach French ");
		System.out.println("What's my name?");
		Scanner sc = new Scanner(System.in);
		name=sc.nextLine();
		System.out.println("Oh, my name is "+ name);
		sc.close();
	}
	French(int x){
		super(x);
		System.out.println("Shit");
		super.teaches();
	}
	public void teaches(){
		System.out.println("I love french");
	}
	public void importance(){
		System.out.println("My importance is "+(imp*1.25));
	}
}
