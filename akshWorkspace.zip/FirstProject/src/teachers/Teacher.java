package teachers;

public class Teacher {
	int teachId,imp;
	String name;
	Teacher(){
		System.out.print("So I'm a teacher and ");
	}

	Teacher(int x){
		System.out.print("So I'm a parameterized teacher and ");
	}
	
	public void teaches(){
		System.out.println("again teashcder");
	}
	public void importance(){
		
	}
}
