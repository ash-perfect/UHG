package teachers;

import java.util.Scanner;

public class Computer extends Teacher{
	int imp=10;
	String name;
	Computer(){
		System.out.println("I teach CSE ");
		System.out.println("What's my name?");
		Scanner sc = new Scanner(System.in);
		name=sc.nextLine();
		sc.close();
	}
	public void teaches(){
		System.out.println("I love comps");
	}
	public void importance(){
		System.out.println("My importance is "+(imp*1.25));
	}
}
