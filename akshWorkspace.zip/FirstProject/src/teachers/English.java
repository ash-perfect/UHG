package teachers;

import java.util.Scanner;

public class English extends Teacher{
	int imp=8;
	String name;
	English(){
		System.out.println("I teach english ");
		System.out.println("What's my name?");
		Scanner sc = new Scanner(System.in);
		name=sc.nextLine();
		sc.close();
	}
	public void teaches(){
		System.out.println("I love grammer");
	}
	public void importance(){
		System.out.println("My importance is "+(imp*1.25));
	}
}
