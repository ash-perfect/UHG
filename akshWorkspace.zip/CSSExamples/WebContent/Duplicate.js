/**
 * 
 */
function checkDup(){
	var firstStr= document.getElementById("box").value;
	var strSplit = firstStr.split(" ");
	document.write(strSplit);
	var ar = new Array();
	var arn = new Array();
	document.writeln(firstStr.search(strSplit[2]));
	var dups=0;
		for (var int2 = 0; int2 < strSplit.length; int2++) {
			
			if(ar.includes(strSplit[int2]))
				dups=dups+1;
			else
				ar.push(strSplit[int2]);
		}
	for (var int = 0; int < ar.length; int++) {
		arn.push(-1);
	}
	for (var int2 = 0; int2 < strSplit.length; int2++) {
		
		if(ar.includes(strSplit[int2]))
			arn[ar.indexOf(strSplit[int2])]=arn[ar.indexOf(strSplit[int2])]+1;
	}
	var aa=document.getElementsByTagName("UL");
	aa[0].innerHTML=ar[0]+" ";
	document.writeln("\n")
	document.writeln(ar);
	document.writeln(arn);
	document.writeln(dups);
}