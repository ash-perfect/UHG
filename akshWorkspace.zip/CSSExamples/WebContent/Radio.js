/**
 * 
 */

function radioFun(choice){
	b= document.getElementsByTagName("BODY")[0];
	if(choice=="blue")
		b.style.background="aqua";
	else
		b.style.background="red";
			
}

function checkFlu(){
	var ch = document.getElementById("eng");
	if(ch.checked == true)
		document.getElementById("doub").style.display = "block";
	else if(ch.checked == false)
		document.getElementById("doub").style.display = "none";
}

function checkFluency()
{
	let lang = new Array();
	var ch = document.getElementsByName("cch");
	
	for(var i=0;i<ch.length;i++)
		{
	if(ch[i].checked == true)
		{
		lang.push(ch[i].value);
		}
	}
	document.getElementById("res").innerHTML = lang;
}
