/**
 * 
 */
var input = document.getElementById("b1");
	input.addEventListener("keyup", function(event){
	event.preventDefault();
	if(event.keyCode === 13){
		document.getElementById("b1").click();
	}
});
	function myprompt() {
		let note = document.getElementById("demo").value;
		//document.write(input);
		document.getElementById("sp").innerHTML=note;
	}
	function addnum(){
		let input = document.getElementById("first").value;
		let input2 = document.getElementById("sec").value;
		var res = parseInt(input)+parseInt(input2);
		document.getElementById("sp").innerHTML = res;
	}function subnum(){
		let input = document.getElementById("first").value;
		let input2 = document.getElementById("sec").value;
		var res = parseInt(input)-parseInt(input2);
		document.getElementById("sp").innerHTML = res;
	}function mulnum(){
		let input = document.getElementById("first").value;
		let input2 = document.getElementById("sec").value;
		var res = parseInt(input)*parseInt(input2);
		document.getElementById("sp").innerHTML = res;
	}function divnum(){
		let input = document.getElementById("first").value;
		let input2 = document.getElementById("sec").value;
		var res = parseInt(input)/parseInt(input2);
		document.getElementById("sp").innerHTML = res;
	}
	
	function mycls(){
		var divv = document.getElementsByClassName("divs");
		divv[1].innerHTML = "Replaced";
		var l = divv.length;
		divv[0].innerHTML = "we're" + l;
	}
	
	function mytag(){
		var list = document.getElementsByTagName("UL") [0];
		list.getElementsByTagName("LI")[0].innerHTML = "1. Dosa Kali";
	}
	function myname(){
		var x = document.getElementsByName("name1")[0].value;
		var y = document.getElementsByName("name1")[1].value;
		if(x==y){
			var x =document.getElementById("done");
			x.innerHTML = "Matched";
			x.style.color = "green";
		}
		else{
			var x =document.getElementById("done");
			x.innerHTML = "Not Matched";
			x.style.color = "red";
		}
	}