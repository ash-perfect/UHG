package login;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Register_Servlet
 */
@WebServlet("/Register_Servlet")
public class Register_Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	boolean checker = true;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String rname = request.getParameter("username");
		PrintWriter out = response.getWriter();
		String rpwd = request.getParameter("password");
		String rmob = request.getParameter("mobile");
		String rcity = request.getParameter("city");
		String rgen = request.getParameter("gen");
		out.println(rgen);
		checkU(rname);
		checkPass(rpwd);
		checkMob(Long.parseLong(rmob));
		checkGen(rgen);
		try {
			if(checker){
				out.println("WRONG DATA");}
			else{
			String Query = "insert into register values(autoID.nextval,?,?,?,?,?)";
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","root");
			PreparedStatement pstmt = con.prepareStatement(Query);
			pstmt.setString(1, rname);
			pstmt.setString(2, rpwd);
			pstmt.setString(3, rmob);
			pstmt.setString(4, rcity);
			pstmt.setString(5, rgen);
			int n = pstmt.executeUpdate();
			if(n>0)
				out.println("Sucess");
			else
				out.println("Failure");}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	private void checkMob(long mob) {
		// TODO Auto-generated method stub
		long x= mob/1000000000;
		if(x>=1 && x<10){
			checker =false;
			return;}
		else {
			System.out.println("Invalid mobile number");
		}
	}

	private void checkGen(String gen) {
		// TODO Auto-generated method stub
		if(gen.toLowerCase().equals("male")||gen.toLowerCase().equals("female")){
			checker=false;
			return;
		}
		else
			System.out.println("Invalid gender");
	}

	private void checkPass(String pass) {
		// TODO Auto-generated method stub
		if(pass.length()<8){
			System.out.println("Password too short");
			return;
		}
		if(Character.isLowerCase(pass.toCharArray()[0])){
			System.out.println("First letter upper case please");
			return;
		}
		char[] ch = pass.toCharArray();
		boolean flag = false;
		boolean flag2 = false;
		for(int i =0;i<pass.length();i++){
			if(Character.isLetter(ch[i]))
				;
			else if(Character.isDigit(ch[i]))
				flag2=true;
			else
				flag=true;
		}
		if(flag == false){
			System.out.println("Please have a special character");
			return;
		}
		if(flag2== false){
			System.out.println("Please end with a number");
			return;
		}
		checker=false;
	}

	private void checkU(String uname) {
		// TODO Auto-generated method stub
		if(uname.length()<8){
			System.out.println("Password too short");
			return;
		}
		char[] ch = uname.toCharArray();
		boolean flag = false;
		for(int i =0;i<uname.length();i++){
			if(Character.isLetterOrDigit(ch[i]))
				;
			else
				flag=true;
		}
		if(flag){
			System.out.println("Shouldn\'t contain special chars");
			return;
		}
		checker=false;
		
	}


}
